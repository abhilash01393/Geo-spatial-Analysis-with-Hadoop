import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 * main!
 * 
 */
public class equijoin {

	public static String t1Name = "";
	public static String t2Name = "";

	public static class Map extends Mapper<Text, Text, Text, Text> {

		private Text joinCol = new Text();
		private Text valLine = new Text();

		public void map(Text key, Text value, Context context)
				throws IOException, InterruptedException {

			String line = key.toString();
			String[] cols = key.toString().split(",");

			if (line != null) {
				if (t1Name.isEmpty())
					t1Name = cols[0];
				else {
					if (!t1Name.equals(cols[0])) {
						t2Name = cols[0];
					}
				}
			}

			joinCol.set(cols[1]);
			valLine.set(line);
			context.write(joinCol, valLine);

		}
	}

	public static class Reduce extends Reducer<Text, Text, Text, Text> {
		public Text result = new Text();

		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {

			ArrayList<String> t1 = new ArrayList<String>();
			ArrayList<String> t2 = new ArrayList<String>();

			for (Text text : values) {
				String[] str = text.toString().split(",");
				if (str != null && str[0].trim().equals(t1Name)) {
					t1.add(text.toString());
				} else if (str != null && str[0].trim().equals(t2Name)) {
					t2.add(text.toString());
				}

			}

			String stringData = "";
			for (int i = 0; i < t1.size(); i++) {

				for (int j = 0; j < t2.size(); j++) {

					stringData = t1.get(i) + ", " + t2.get(j);
					result.set(stringData);
					context.write(null, result);
					result.clear();
				}
			}

		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		Job job = new Job(conf, "equiJoin");
		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);

		job.setInputFormatClass(KeyValueTextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.waitForCompletion(true);
	}

}
