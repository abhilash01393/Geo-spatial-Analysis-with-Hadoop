README

To run the script, apply chmod +x to the script, just in case it doesn't run.
The script runs for 1 hour, i.e., for computations involving more than 1 hour, update the script.
Run the script before spark-submit.